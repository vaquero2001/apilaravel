<?php echo e($slot); ?>

<?php /**PATH C:\Users\Ivan\Documents\tareas de la uni\estadia ingenieria\example-app\apilaravel\apilaravel_back\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>